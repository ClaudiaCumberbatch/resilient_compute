
export JOBNAME=$parsl.htex_Local.block-0.1711585373.9109197
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:43493 PARSL_MONITORING_RADIO_MODE=diaspora PARSL_RUN_ID=abaf0db5-6b3d-4f01-9b47-a3811b625a16 PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/530 process_worker_pool.py --debug --max_workers=32 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54831 --result_port=54912 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/530/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid f58cae3655e4 --monitor_resources --monitoring_url udp://localhost:43493 --run_id abaf0db5-6b3d-4f01-9b47-a3811b625a16 --radio_mode diaspora --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
