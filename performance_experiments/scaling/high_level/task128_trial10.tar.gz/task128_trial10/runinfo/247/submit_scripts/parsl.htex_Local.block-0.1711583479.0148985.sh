
export JOBNAME=$parsl.htex_Local.block-0.1711583479.0148985
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:60896 PARSL_MONITORING_RADIO_MODE=htex PARSL_RUN_ID=329cd58b-9c9f-4c5d-84b9-a8a30608cb2d PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/247 process_worker_pool.py --debug --max_workers=4 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54335 --result_port=54403 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/247/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 78570459482f --monitor_resources --monitoring_url udp://localhost:60896 --run_id 329cd58b-9c9f-4c5d-84b9-a8a30608cb2d --radio_mode htex --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
