
export JOBNAME=$parsl.htex_Local.block-0.1711584148.1654482
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=fake PARSL_MONITORING_RADIO_MODE=htex PARSL_RUN_ID=ae2b9d33-0f05-4b5c-a2f4-be11192e0602 PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/343 process_worker_pool.py --debug --max_workers=8 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54884 --result_port=54753 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/343/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid b8f6caaf7005  --monitoring_url fake --run_id ae2b9d33-0f05-4b5c-a2f4-be11192e0602 --radio_mode htex --sleep_dur 0 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
