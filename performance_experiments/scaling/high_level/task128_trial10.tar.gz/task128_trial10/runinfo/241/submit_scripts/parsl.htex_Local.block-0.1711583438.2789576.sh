
export JOBNAME=$parsl.htex_Local.block-0.1711583438.2789576
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:56861 PARSL_MONITORING_RADIO_MODE=diaspora PARSL_RUN_ID=57266769-6a59-476d-987c-cf90d18f93be PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/241 process_worker_pool.py --debug --max_workers=4 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54634 --result_port=54781 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/241/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 9a5080f6dea0 --monitor_resources --monitoring_url udp://localhost:56861 --run_id 57266769-6a59-476d-987c-cf90d18f93be --radio_mode diaspora --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
