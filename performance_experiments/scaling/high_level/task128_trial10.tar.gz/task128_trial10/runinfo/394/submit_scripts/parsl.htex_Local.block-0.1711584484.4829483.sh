
export JOBNAME=$parsl.htex_Local.block-0.1711584484.4829483
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:46769 PARSL_MONITORING_RADIO_MODE=diaspora PARSL_RUN_ID=5baeff43-b3a4-4a8e-9797-45d70d9a2bb9 PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/394 process_worker_pool.py --debug --max_workers=16 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54169 --result_port=54809 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/394/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 56172b63a15f --monitor_resources --monitoring_url udp://localhost:46769 --run_id 5baeff43-b3a4-4a8e-9797-45d70d9a2bb9 --radio_mode diaspora --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
