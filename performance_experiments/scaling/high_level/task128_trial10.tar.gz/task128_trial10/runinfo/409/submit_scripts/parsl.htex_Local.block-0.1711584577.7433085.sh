
export JOBNAME=$parsl.htex_Local.block-0.1711584577.7433085
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:59643 PARSL_MONITORING_RADIO_MODE=htex PARSL_RUN_ID=8f9137e1-b803-434f-88ed-ede30c646079 PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/409 process_worker_pool.py --debug --max_workers=16 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54141 --result_port=54828 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/409/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 1fa29a4817ee --monitor_resources --monitoring_url udp://localhost:59643 --run_id 8f9137e1-b803-434f-88ed-ede30c646079 --radio_mode htex --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
