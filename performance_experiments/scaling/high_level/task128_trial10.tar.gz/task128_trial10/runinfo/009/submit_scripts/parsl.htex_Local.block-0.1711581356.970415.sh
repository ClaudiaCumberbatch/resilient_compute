
export JOBNAME=$parsl.htex_Local.block-0.1711581356.970415
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=fake PARSL_MONITORING_RADIO_MODE=htex PARSL_RUN_ID=8a85e216-540b-4dc2-9afb-c07e9c9873e4 PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/009 process_worker_pool.py --debug --max_workers=1 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54111 --result_port=54398 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/009/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 9d94dccc9101  --monitoring_url fake --run_id 8a85e216-540b-4dc2-9afb-c07e9c9873e4 --radio_mode htex --sleep_dur 0 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
