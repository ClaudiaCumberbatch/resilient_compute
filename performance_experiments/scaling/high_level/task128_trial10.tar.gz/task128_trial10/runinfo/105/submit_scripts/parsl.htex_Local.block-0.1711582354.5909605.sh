
export JOBNAME=$parsl.htex_Local.block-0.1711582354.5909605
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:60283 PARSL_MONITORING_RADIO_MODE=diaspora PARSL_RUN_ID=1a0f4155-ea76-4c52-9c83-bd34823ce149 PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/105 process_worker_pool.py --debug --max_workers=2 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54362 --result_port=54214 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/105/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid de7f3bb4b3ae --monitor_resources --monitoring_url udp://localhost:60283 --run_id 1a0f4155-ea76-4c52-9c83-bd34823ce149 --radio_mode diaspora --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
