
export JOBNAME=$parsl.htex_Local.block-0.1711568390.3670144
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:41040 PARSL_MONITORING_RADIO_MODE=htex PARSL_RUN_ID=525ed89c-8288-48e6-9d8a-8991609ffb0c PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/094 process_worker_pool.py --debug --max_workers=8 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54182 --result_port=54001 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/094/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 0ec0132b4d1d --monitor_resources --monitoring_url udp://localhost:41040 --run_id 525ed89c-8288-48e6-9d8a-8991609ffb0c --radio_mode htex --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
