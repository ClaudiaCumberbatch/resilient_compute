
export JOBNAME=$parsl.htex_Local.block-0.1711567860.1030455
set -e
export CORES=$(getconf _NPROCESSORS_ONLN)
[[ "1" == "1" ]] && echo "Found cores : $CORES"
WORKERCOUNT=1
FAILONANY=0
PIDS=""

CMD() {
PARSL_MONITORING_HUB_URL=udp://localhost:60999 PARSL_MONITORING_RADIO_MODE=diaspora PARSL_RUN_ID=54550415-9fc1-4970-ad44-8838ee61d9bb PARSL_RUN_DIR=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/026 process_worker_pool.py --debug --max_workers=1 -a 127.0.0.1 -p 0 -c 1 -m None --poll 100 --task_port=54705 --result_port=54330 --cert_dir None --logdir=/home/cc/resilient_compute/performance_experiments/scaling/high_level/runinfo/026/htex_Local --block_id=0 --hb_period=2  --hb_threshold=5 --cpu-affinity none --available-accelerators --uid 764af4bc8643 --monitor_resources --monitoring_url udp://localhost:60999 --run_id 54550415-9fc1-4970-ad44-8838ee61d9bb --radio_mode diaspora --sleep_dur 10 
}
for COUNT in $(seq 1 1 $WORKERCOUNT); do
    [[ "1" == "1" ]] && echo "Launching worker: $COUNT"
    CMD $COUNT &
    PIDS="$PIDS $!"
done

ALLFAILED=1
ANYFAILED=0
for PID in $PIDS ; do
    wait $PID
    if [ "$?" != "0" ]; then
        ANYFAILED=1
    else
        ALLFAILED=0
    fi
done

[[ "1" == "1" ]] && echo "All workers done"
if [ "$FAILONANY" == "1" ]; then
    exit $ANYFAILED
else
    exit $ALLFAILED
fi
